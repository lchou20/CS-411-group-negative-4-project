const mongoose = require('mongoose');

// Define the user schema
const userSchema = new mongoose.Schema({
  googleId: {
    type: String,
    required: true,
    unique: true,
  },
  name: {
    type: String,
    required: true,
  },
  // Add more fields as needed
});

// Create the User model
const User = mongoose.model('User', userSchema);

module.exports = User;
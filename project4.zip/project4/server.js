require('dotenv').config();

//import axios from 'axios';
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const inMemoryUsers = []; // In-memory storage for users
const PORT = process.env.PORT || 3000;

const app = express();
app.use(bodyParser.json());
const crypto = require('crypto');

// Generate a random 32-byte (256-bit) key
const secretKey = crypto.randomBytes(32).toString('hex');

console.log('Generated Secret Key:', secretKey);
app.use(session({ secret: secretKey, resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());
// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Passport serialization and deserialization
passport.serializeUser((user, done) => {
  done(null, user.googleId);
});

passport.deserializeUser((id, done) => {
  const user = inMemoryUsers.find(u => u.googleId === id);
  done(null, user);
});

// Passport configuration
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: "/auth/google/callback"
},
async (accessToken, refreshToken, profile, cb) => {
  try {
    // Check if user already exists in the in-memory array
    let user = inMemoryUsers.find(u => u.googleId === profile.id);
    if (!user) {
      // If not, create a new user in the in-memory array
      user = { googleId: profile.id, name: profile.displayName };
      inMemoryUsers.push(user);
    }

    console.log('User:', user);
    return cb(null, user);
  } catch (error) {
    return cb(error);
  }
}));

app.use(passport.initialize());

// Define the Google authentication routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get(
  '/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    // Successful authentication, redirect home.
    res.redirect('/');
  },
  (error, req, res, next) => {
    // Handle errors that occur during authentication
    console.error('Authentication error:', error);
    res.status(500).json({ error: 'Authentication Error' });
  }
);

app.post('/find-hotel', async (req, res) => {
  try {
    const { address } = req.body;

    console.log(`Received request for address: ${address}`);

    // Use Google Places API to find the closest hotel
    const geoResponse = await axios.get(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
        address
      )}&key=${process.env.GEOCODING_API_KEY}`
    );

    console.log('Geocoding response:', geoResponse.data);

    // Check if the geocoding request was successful
    if (geoResponse.data.status !== 'OK') {
      console.error('Geocoding API error:', geoResponse.data.error_message);
      return res.status(500).json({ error: 'Geocoding API Error' });
    }

    const { lat, lng } = geoResponse.data.results[0]?.geometry?.location || {};

    // Use Google Places API to find the closest hotel
    const placesResponse = await axios.get(
      `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=5000&type=lodging&key=${process.env.PLACES_API_KEY}`
    );

    //console.log('Google Places API response:', placesResponse.data);

    // Check if the Google Places request was successful
    if (placesResponse.data.status !== 'OK') {
      console.error('Google Places API error:', placesResponse.data.error_message);
      return res.status(500).json({ error: 'Google Places API Error' });
    }

    const closestHotel = placesResponse.data.results[0];

    console.log('Hotel information from Google Places API:', closestHotel);

    const cityGeoResponse = await axios.get(
      `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&result_type=locality&key=${process.env.GEOCODING_API_KEY}`
    );

    const city = cityGeoResponse.data.results[0]?.address_components.find(component => component.types.includes('locality'))?.long_name || 'Unknown City';
    console.log('City information from Google Geocoding API:', city);
    const weatherstackApiKey = process.env.WEATHERSTACK_API_KEY;
    const weatherResponse = await axios.get(
      `http://api.weatherstack.com/current?access_key=${weatherstackApiKey}&query=${encodeURIComponent(city)}`
    );
    const weatherData = weatherResponse.data.current;
    console.log('Weather information from Weatherstack API:', weatherData);

    res.json({
      hotel: { name: closestHotel.name, vicinity: closestHotel.vicinity },
      city: city,
      weather: {
        temperature: weatherData.temperature,
        weatherDescription: weatherData.weather_descriptions[0],
        speed: weatherData.wind_speed,
        humidity: weatherData.humidity,
        feelslike: weatherData.feelslike,
        visibility: weatherData.visibility,

      },
    });
  } catch (error) {
    console.error('Error in /find-hotel route:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
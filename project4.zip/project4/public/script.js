document.addEventListener('DOMContentLoaded', function () {
  console.log('DOM content loaded');

  document.getElementById('findHotelButton').addEventListener('click', findHotel);

  async function findHotel() {
    console.log('Function called');
  
    const address = document.getElementById('address').value;
    console.log('Address:', address);
  
    const resultContainer = document.getElementById('result');
  
    try {
      const response = await fetch('/find-hotel', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ address }),
      });
  
      console.log('Response:', response);
  
      const data = await response.json();
  
      console.log('Data:', data);
  
      if (data.error) {
        resultContainer.innerHTML = `<p>Error: ${data.error}</p>`;
      } else {
        const hotel = data.hotel;
        const city = data.city;
        const weather = data.weather;
      
        resultContainer.innerHTML = `<p>Closest Hotel:</p>
                                     <p>Name: ${hotel.name}</p>
                                     <p>Address: ${hotel.vicinity}</p>
                                     <p>City: ${city}</p>
                                     <p>Temperature: ${weather.temperature}°C</p>
                                     <p>Weather: ${weather.weatherDescription}</p>
                                     <p>Windspeed: ${weather.speed}</p>
                                     <p>Humidity: ${weather.humidity}</p>
                                     <p>Feels Like: ${weather.feelslike}°C</p>
                                     <p>Visibility: ${weather.visibility}</p>`
                                     
      }
    } catch (error) {
      console.error(error);
      resultContainer.innerHTML = `<p>Error: Internal Server Error</p>`;
    }
  }
});